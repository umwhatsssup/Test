g.py this is registration

main.py this is chat

if main.py closing then launch main.py later

connect in Radmin VPN to Server112233aa