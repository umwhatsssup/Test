import pygame
import socket
import pickle
import sys
import random
import threading
import pyperclip
import psutil
import struct

# --- Налаштування гри ---
CELL_SIZE = 20                   # Розмір клітинки
FPS = 10                         # Кількість кадрів на секунду
PORT = 5555                      # Порт для сервера
MAX_PLAYERS = 4                  # Максимальна кількість гравців у мультиплеєрі

# Кольори для гравців (за замовчуванням)
PLAYER_COLORS = [
    (0, 255, 0),
    (255, 0, 0),
    (0, 128, 255),
    (255, 128, 0)
]

# --- Ініціалізація pygame та шрифтів ---
pygame.init()
FONT = pygame.font.SysFont("Arial", 32)
SMALL_FONT = pygame.font.SysFont("Arial", 24)

# --- Глобальні змінні для розміру карти ---
MAP_SIZES = [
    (50, 50),    # 1 - маленька
    (100, 100),    # 2 - середня
    (150, 150),    # 3 - велика
    (200, 200)   # 4 - найбільша
]
MAP_SIZE_LABELS = [
    "1 (50x50)", "2 (100x100)", "3 (150x150)", "4 (200x200)"
]

# --- Допоміжні функції ---
def get_ip():
    """Повертає локальний IP-адрес."""
    return socket.gethostbyname(socket.gethostname())

def get_radmin_ip():
    """Повертає IP-адресу Radmin VPN (якщо є), інакше локальний IP."""
    for iface, addrs in psutil.net_if_addrs().items():
        if "Radmin" in iface:
            for addr in addrs:
                if addr.family == socket.AF_INET:
                    return addr.address
    return get_ip()

def random_pos(snakes, map_w, map_h):
    """Генерує випадкову позицію для їжі, яка не співпадає з жодною змійкою."""
    while True:
        pos = (random.randint(0, map_w-1), random.randint(0, map_h-1))
        if all(pos not in snake.body for snake in snakes):
            return pos

def send_data(sock, data):
    """Відправляє дані через сокет (з префіксом довжини)."""
    try:
        msg = pickle.dumps(data)
        msg = struct.pack('>I', len(msg)) + msg
        sock.sendall(msg)
    except Exception as e:
        print("Помилка відправки:", e)

def recv_data(sock):
    """Отримує дані через сокет (чекає повний pickle-об'єкт)."""
    try:
        raw_msglen = recvall(sock, 4)
        if not raw_msglen:
            return None
        msglen = struct.unpack('>I', raw_msglen)[0]
        data = recvall(sock, msglen)
        if not data:
            return None
        return pickle.loads(data)
    except Exception:
        return None

def recvall(sock, n):
    """Отримує n байтів або повертає None, якщо з'єднання закрите."""
    data = b''
    while len(data) < n:
        packet = sock.recv(n - len(data))
        if not packet:
            return None
        data += packet
    return data

def draw_center_text(screen, text, y, color=(255,255,255), font=FONT):
    """Малює текст по центру екрана."""
    txt = font.render(text, True, color)
    screen.blit(txt, txt.get_rect(center=(screen.get_width()//2, y)))

# --- Класи ---
class Button:
    """Кнопка для меню."""
    def __init__(self, rect, text):
        self.rect = pygame.Rect(rect)
        self.text = text

    def draw(self, screen, active=True):
        color = (70, 130, 180) if active else (80, 80, 80)
        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, (255,255,255), self.rect, 2)
        txt = FONT.render(self.text, True, (255,255,255) if active else (180,180,180))
        screen.blit(txt, txt.get_rect(center=self.rect.center))

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

class Checkbox:
    """Чекбокс для меню."""
    def __init__(self, rect, label, checked=False):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.checked = checked

    def draw(self, screen, active=True):
        color = (255,255,255) if active else (120,120,120)
        pygame.draw.rect(screen, color, self.rect, 2)
        if self.checked:
            pygame.draw.line(screen, color, self.rect.topleft, self.rect.bottomright, 3)
            pygame.draw.line(screen, color, self.rect.topright, self.rect.bottomleft, 3)
        txt = SMALL_FONT.render(self.label, True, color)
        screen.blit(txt, (self.rect.right + 10, self.rect.y))

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)

class Snake:
    """Клас змійки."""
    def __init__(self, color, pos):
        self.body = [pos]
        self.dir = (1, 0)
        self.color = color
        self.grow = False

    def move(self):
        """Рухає змійку вперед."""
        head = (self.body[0][0] + self.dir[0], self.body[0][1] + self.dir[1])
        self.body.insert(0, head)
        if not self.grow:
            self.body.pop()
        else:
            self.grow = False

    def change_dir(self, d):
        """Змінює напрямок руху змійки."""
        if (d[0] != -self.dir[0] or d[1] != -self.dir[1]):
            self.dir = d

    def eat(self):
        """Збільшує змійку після їжі."""
        self.grow = True

    def out_of_bounds(self, map_w, map_h):
        """Перевіряє, чи вийшла змійка за межі карти."""
        x, y = self.body[0]
        return not (0 <= x < map_w and 0 <= y < map_h)

# --- Меню налаштувань карти ---
def settings_screen(screen, default_size=1, allow_players=False, allow_code=False, allow_network=True):
    """
    Меню налаштувань карти перед грою.
    Дозволяє вибрати розмір карти, кількість гравців, мережу чи код кімнати.
    """
    map_size = default_size
    max_players = 2
    room_code = ""
    input_active = False
    code_active = False
    code_box = pygame.Rect(screen.get_width()//2-100, 260, 200, 40)
    players_box = pygame.Rect(screen.get_width()//2-100, 320, 200, 40)
    network_checkbox = Checkbox((screen.get_width()//2-100, 380, 20, 20), "Локальна мережа", checked=True)
    code_checkbox = Checkbox((screen.get_width()//2+40, 380, 20, 20), "Код кімнати", checked=False)
    ok_btn = Button((screen.get_width()//2-120, 430, 240, 60), "OK")
    clock = pygame.time.Clock()
    while True:
        screen.fill((30,30,30))
        draw_center_text(screen, "Налаштування", 60)
        # Вибір розміру карти
        draw_center_text(screen, "Розмір карти:", 120, font=SMALL_FONT)
        for i, label in enumerate(MAP_SIZE_LABELS):
            color = (255,255,255) if i == map_size else (180,180,180)
            txt = SMALL_FONT.render(label, True, color)
            screen.blit(txt, (screen.get_width()//2-100 + i*90, 150))
            pygame.draw.rect(screen, color, (screen.get_width()//2-110 + i*90, 145, 80, 35), 2 if i == map_size else 1)
        # Додаткові поля
        y = 200
        if allow_players:
            draw_center_text(screen, "Макс. гравців (2-4):", 230, font=SMALL_FONT)
            pygame.draw.rect(screen, (255,255,255), players_box, 2)
            txt = SMALL_FONT.render(str(max_players), True, (255,255,255))
            screen.blit(txt, (players_box.x+5, players_box.y+5))
        if allow_code:
            draw_center_text(screen, "Код кімнати:", 290, font=SMALL_FONT)
            pygame.draw.rect(screen, (255,255,255) if code_checkbox.checked else (120,120,120), code_box, 2)
            txt = SMALL_FONT.render(room_code, True, (255,255,255) if code_checkbox.checked else (120,120,120))
            screen.blit(txt, (code_box.x+5, code_box.y+5))
        if allow_network and allow_code:
            network_checkbox.draw(screen, active=not code_checkbox.checked)
            code_checkbox.draw(screen, active=not network_checkbox.checked)
        ok_btn.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Вибір розміру карти
                for i in range(len(MAP_SIZE_LABELS)):
                    rect = pygame.Rect(screen.get_width()//2-110 + i*90, 145, 80, 35)
                    if rect.collidepoint(event.pos):
                        map_size = i
                if allow_players and players_box.collidepoint(event.pos):
                    input_active = True
                    code_active = False
                elif allow_code and code_box.collidepoint(event.pos) and code_checkbox.checked:
                    code_active = True
                    input_active = False
                else:
                    input_active = False
                    code_active = False
                if allow_network and allow_code:
                    if network_checkbox.is_clicked(event.pos):
                        network_checkbox.checked = True
                        code_checkbox.checked = False
                    elif code_checkbox.is_clicked(event.pos):
                        code_checkbox.checked = True
                        network_checkbox.checked = False
                if ok_btn.is_clicked(event.pos):
                    return {
                        "map_size": map_size,
                        "max_players": max_players if allow_players else None,
                        "room_code": room_code if allow_code and code_checkbox.checked else None,
                        "use_network": network_checkbox.checked if allow_network and allow_code else None
                    }
            elif event.type == pygame.KEYDOWN:
                if input_active and allow_players:
                    if event.key == pygame.K_BACKSPACE:
                        max_players = int(str(max_players)[:-1]) if len(str(max_players)) > 1 else 2
                    elif event.unicode.isdigit():
                        val = int(str(max_players) + event.unicode)
                        if 2 <= val <= 4:
                            max_players = val
                if code_active and allow_code and code_checkbox.checked:
                    if event.key == pygame.K_BACKSPACE:
                        room_code = room_code[:-1]
                    elif len(room_code) < 8 and event.unicode.isalnum():
                        room_code += event.unicode
        pygame.display.flip()
        clock.tick(30)

def menu_screen(screen):
    """
    Головне меню гри.
    Дозволяє вибрати режим: соло, хост або підключення.
    """
    btn_width = 320
    btn_height = 70
    btn_gap = 50
    center_x = screen.get_width() // 2
    start_y = 120

    solo_btn = Button((center_x - btn_width//2, start_y, btn_width, btn_height), "Грати самому")
    host_btn = Button((center_x - btn_width//2, start_y + btn_height + btn_gap, btn_width, btn_height), "Захостити гру")
    join_btn = Button((center_x - btn_width//2, start_y + 2*(btn_height + btn_gap), btn_width, btn_height), "Підключитись")
    clock = pygame.time.Clock()
    while True:
        screen.fill((30,30,30))
        draw_center_text(screen, "Змійка", 60)
        solo_btn.draw(screen)
        host_btn.draw(screen)
        join_btn.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if solo_btn.is_clicked(event.pos):
                    settings = settings_screen(screen, default_size=1)
                    return "solo", settings
                if host_btn.is_clicked(event.pos):
                    settings = settings_screen(screen, default_size=1, allow_players=True, allow_code=True, allow_network=True)
                    return "host", settings
                if join_btn.is_clicked(event.pos):
                    join_settings = join_screen(screen)
                    return "join", join_settings
        pygame.display.flip()
        clock.tick(30)

def join_screen(screen):
    """
    Меню підключення до гри.
    Дозволяє ввести IP або код кімнати для підключення.
    """
    network_checkbox = Checkbox((screen.get_width()//2-100, 120, 20, 20), "Локальна мережа", checked=True)
    code_checkbox = Checkbox((screen.get_width()//2+40, 120, 20, 20), "Код кімнати", checked=False)
    ip_box = pygame.Rect(screen.get_width()//2-100, 180, 200, 40)
    code_box = pygame.Rect(screen.get_width()//2-100, 240, 200, 40)
    input_active = False
    code_active = False
    ip_text = ""
    room_code = ""
    join_btn = Button((screen.get_width()//2-120, 320, 240, 60), "Підключитись")
    clock = pygame.time.Clock()
    while True:
        screen.fill((30,30,30))
        draw_center_text(screen, "Підключення", 60)
        network_checkbox.draw(screen, active=not code_checkbox.checked)
        code_checkbox.draw(screen, active=not network_checkbox.checked)
        pygame.draw.rect(screen, (255,255,255) if network_checkbox.checked else (120,120,120), ip_box, 2)
        txt = SMALL_FONT.render(ip_text, True, (255,255,255) if network_checkbox.checked else (120,120,120))
        screen.blit(txt, (ip_box.x+5, ip_box.y+5))
        draw_center_text(screen, "IP:", 200, font=SMALL_FONT)
        pygame.draw.rect(screen, (255,255,255) if code_checkbox.checked else (120,120,120), code_box, 2)
        txt = SMALL_FONT.render(room_code, True, (255,255,255) if code_checkbox.checked else (120,120,120))
        screen.blit(txt, (code_box.x+5, code_box.y+5))
        draw_center_text(screen, "Код кімнати:", 260, font=SMALL_FONT)
        join_btn.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if network_checkbox.is_clicked(event.pos):
                    network_checkbox.checked = True
                    code_checkbox.checked = False
                elif code_checkbox.is_clicked(event.pos):
                    code_checkbox.checked = True
                    network_checkbox.checked = False
                if ip_box.collidepoint(event.pos) and network_checkbox.checked:
                    input_active = True
                    code_active = False
                elif code_box.collidepoint(event.pos) and code_checkbox.checked:
                    code_active = True
                    input_active = False
                else:
                    input_active = False
                    code_active = False
                if join_btn.is_clicked(event.pos):
                    return {
                        "use_network": network_checkbox.checked,
                        "ip": ip_text if network_checkbox.checked else None,
                        "room_code": room_code if code_checkbox.checked else None
                    }
            elif event.type == pygame.KEYDOWN:
                if input_active and network_checkbox.checked:
                    if event.key == pygame.K_BACKSPACE:
                        ip_text = ip_text[:-1]
                    elif len(ip_text) < 15 and (event.unicode.isdigit() or event.unicode == "."):
                        ip_text += event.unicode
                if code_active and code_checkbox.checked:
                    if event.key == pygame.K_BACKSPACE:
                        room_code = room_code[:-1]
                    elif len(room_code) < 8 and event.unicode.isalnum():
                        room_code += event.unicode
        pygame.display.flip()
        clock.tick(30)

def end_screen(screen, message):
    """
    Екран після програшу з кнопками "Головне меню" та "Респавн".
    """
    btn_width = 320
    btn_height = 70
    btn_gap = 50
    center_x = screen.get_width() // 2
    start_y = 220

    menu_btn = Button((center_x - btn_width//2, start_y, btn_width, btn_height), "Головне меню")
    respawn_btn = Button((center_x - btn_width//2, start_y + btn_height + btn_gap, btn_width, btn_height), "Респавн")
    clock = pygame.time.Clock()
    while True:
        screen.fill((30,30,30))
        draw_center_text(screen, message, 120, color=(255,80,80))
        menu_btn.draw(screen)
        respawn_btn.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if menu_btn.is_clicked(event.pos):
                    return "menu"
                if respawn_btn.is_clicked(event.pos):
                    return "respawn"
        pygame.display.flip()
        clock.tick(30)

def solo_game(screen, settings):
    """
    Гра для одного гравця.
    Керує змійкою, їжею, перевіряє програш.
    """
    map_w, map_h = MAP_SIZES[settings["map_size"]]
    info = pygame.display.Info()
    screen = pygame.display.set_mode((info.current_w, info.current_h), pygame.FULLSCREEN)
    cell_w = info.current_w // map_w
    cell_h = info.current_h // map_h
    cell_size = min(cell_w, cell_h)
    offset_x = (info.current_w - cell_size * map_w) // 2
    offset_y = (info.current_h - cell_size * map_h) // 2

    snake = Snake(PLAYER_COLORS[0], (map_w//2, map_h//2))
    food = random_pos([snake], map_w, map_h)
    clock = pygame.time.Clock()
    started = False
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return
                if event.key == pygame.K_UP:
                    snake.change_dir((0,-1))
                    started = True
                if event.key == pygame.K_DOWN:
                    snake.change_dir((0,1))
                    started = True
                if event.key == pygame.K_LEFT:
                    snake.change_dir((-1,0))
                    started = True
                if event.key == pygame.K_RIGHT:
                    snake.change_dir((1,0))
                    started = True
        if started:
            snake.move()
            if snake.body[0] == food:
                snake.eat()
                food = random_pos([snake], map_w, map_h)
            if snake.out_of_bounds(map_w, map_h) or (len(snake.body) > 3 and snake.body[0] in snake.body[1:]):
                res = end_screen(screen, "Ви програли!")
                if res == "menu":
                    return
                elif res == "respawn":
                    snake = Snake(PLAYER_COLORS[0], (map_w//2, map_h//2))
                    food = random_pos([snake], map_w, map_h)
                    started = False
                    continue
        screen.fill((0,0,0))
        draw_snake_fullscreen(screen, [snake], cell_size, offset_x, offset_y)
        draw_food_fullscreen(screen, food, cell_size, offset_x, offset_y)
        pygame.display.flip()
        clock.tick(FPS)

def host_game(screen, settings):
    """
    Запуск сервера та очікування гравців.
    Відображає лобі з кольорами гравців, дозволяє змінювати колір.
    """
    map_w, map_h = MAP_SIZES[settings["map_size"]]
    max_players = settings["max_players"]
    info = pygame.display.Info()
    screen = pygame.display.set_mode((info.current_w, info.current_h), pygame.FULLSCREEN)
    cell_w = info.current_w // map_w
    cell_h = info.current_h // map_h
    cell_size = min(cell_w, cell_h)
    offset_x = (info.current_w - cell_size * map_w) // 2
    offset_y = (info.current_h - cell_size * map_h) // 2

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('', PORT))
    sock.listen(max_players-1)
    ip = get_radmin_ip()
    clients = []
    player_colors = [list(c) for c in PLAYER_COLORS[:max_players]]
    selected_color_idx = 0
    clock = pygame.time.Clock()
    while True:
        screen.fill((30,30,30))
        draw_center_text(screen, f"Ваш IP: {ip}", 80)
        draw_center_text(screen, f"Очікування гравців ({len(clients)+1}/{max_players})...", 140)
        draw_center_text(screen, "Натисніть Enter для старту", 200, font=SMALL_FONT)

        # --- Відображення кольорів гравців у лобі ---
        lobby_x = screen.get_width() // 2 - 220
        lobby_y = 260
        for i in range(max_players):
            rect = pygame.Rect(lobby_x + i*110, lobby_y, 80, 80)
            color = tuple(player_colors[i])
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, (255,255,255), rect, 3)
            num_txt = FONT.render(str(i+1), True, (0,0,0) if sum(color)>400 else (255,255,255))
            screen.blit(num_txt, num_txt.get_rect(center=rect.center))
            if i == 0:
                label = SMALL_FONT.render("Ви", True, (255,255,255))
                screen.blit(label, (rect.x, rect.y-30))
            if i > len(clients):
                wait_txt = SMALL_FONT.render("Очікуємо...", True, (200,200,200))
                screen.blit(wait_txt, (rect.x, rect.y+90))
            else:
                player_txt = SMALL_FONT.render(f"Гравець {i+1}", True, (255,255,255))
                screen.blit(player_txt, (rect.x, rect.y+90))
        color_rect = pygame.Rect(lobby_x, lobby_y+110, 180, 30)
        pygame.draw.rect(screen, (50,50,50), color_rect)
        pygame.draw.rect(screen, (255,255,255), color_rect, 2)
        color_label = SMALL_FONT.render(f"RGB: {player_colors[selected_color_idx]}", True, (255,255,255))
        screen.blit(color_label, (color_rect.x+5, color_rect.y+5))
        color_hint = SMALL_FONT.render("←/→: вибір гравця, R/G/B для зміни", True, (180,180,180))
        screen.blit(color_hint, (lobby_x, lobby_y+150))

        pygame.display.flip()
        sock.settimeout(0.5)
        try:
            conn, addr = sock.accept()
            clients.append(conn)
        except socket.timeout:
            pass
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    selected_color_idx = max(0, selected_color_idx-1)
                if event.key == pygame.K_RIGHT:
                    selected_color_idx = min(len(clients), selected_color_idx+1)
                if event.key == pygame.K_r:
                    player_colors[selected_color_idx][0] = (player_colors[selected_color_idx][0]+5)%256
                if event.key == pygame.K_g:
                    player_colors[selected_color_idx][1] = (player_colors[selected_color_idx][1]+5)%256
                if event.key == pygame.K_b:
                    player_colors[selected_color_idx][2] = (player_colors[selected_color_idx][2]+5)%256
                if event.key == pygame.K_RETURN and len(clients) > 0:
                    for idx, conn in enumerate(clients):
                        try:
                            send_data(conn, {
                                "color": tuple(player_colors[idx+1]),
                                "map_size": settings["map_size"],
                                "max_players": max_players
                            })
                        except Exception as e:
                            print("Помилка відправки кольору:", e)
                    multiplayer_game(
                        screen, clients, is_server=True, map_w=map_w, map_h=map_h,
                        cell_size=cell_size, offset_x=offset_x, offset_y=offset_y,
                        player_colors=[tuple(c) for c in player_colors[:len(clients)+1]]
                    )
                    for c in clients:
                        c.close()
                    return

def join_game(screen, join_settings):
    """
    Підключення до сервера.
    Отримує колір гравця від сервера.
    """
    if join_settings["use_network"]:
        ip = join_settings["ip"]
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.connect((ip, PORT))
        except Exception as e:
            print("Помилка підключення:", e)
            clock = pygame.time.Clock()
            for _ in range(60):
                screen.fill((30,30,30))
                draw_center_text(screen, "Не вдалося підключитись!", 180, color=(255,80,80))
                pygame.display.flip()
                clock.tick(30)
            return
        color = PLAYER_COLORS[1]
        try:
            data = recv_data(sock)
            if isinstance(data, dict):
                color = data.get("color", PLAYER_COLORS[1])
                map_size = data.get("map_size", 1)
                max_players = data.get("max_players", 2)
            else:
                color = PLAYER_COLORS[1]
                map_size = 1
                max_players = 2
            map_w, map_h = MAP_SIZES[map_size]
        except Exception as e:
            print("Помилка отримання кольору:", e)
        map_w, map_h = MAP_SIZES[1]
        info = pygame.display.Info()
        screen = pygame.display.set_mode((info.current_w, info.current_h), pygame.FULLSCREEN)
        cell_w = info.current_w // map_w
        cell_h = info.current_h // map_h
        cell_size = min(cell_w, cell_h)
        offset_x = (info.current_w - cell_size * map_w) // 2
        offset_y = (info.current_h - cell_size * map_h) // 2

        multiplayer_game(
            screen, [sock], is_server=False, map_w=map_w, map_h=map_h,
            cell_size=cell_size, offset_x=offset_x, offset_y=offset_y,
            player_colors=[PLAYER_COLORS[0], color]
        )
        sock.close()
    else:
        clock = pygame.time.Clock()
        for _ in range(60):
            screen.fill((30,30,30))
            draw_center_text(screen, "Підключення через код кімнати не реалізовано!", 180, color=(255,80,80))
            pygame.display.flip()
            clock.tick(30)
        return

def draw_snake(screen, snakes):
    """Малює всіх змійок."""
    for snake in snakes:
        for b in snake.body:
            pygame.draw.rect(screen, snake.color, (b[0]*CELL_SIZE, b[1]*CELL_SIZE, CELL_SIZE, CELL_SIZE))

def draw_food(screen, food):
    """Малює їжу."""
    pygame.draw.rect(screen, (255,255,0), (food[0]*CELL_SIZE, food[1]*CELL_SIZE, CELL_SIZE, CELL_SIZE))

def draw_snake_fullscreen(screen, snakes, cell_size, offset_x, offset_y):
    """Малює змійок у повноекранному режимі."""
    for snake in snakes:
        for b in snake.body:
            pygame.draw.rect(screen, snake.color, (offset_x + b[0]*cell_size, offset_y + b[1]*cell_size, cell_size, cell_size))

def draw_food_fullscreen(screen, food, cell_size, offset_x, offset_y):
    """Малює їжу у повноекранному режимі."""
    pygame.draw.rect(screen, (255,255,0), (offset_x + food[0]*cell_size, offset_y + food[1]*cell_size, cell_size, cell_size))

def multiplayer_game(screen, connections, is_server, map_w, map_h, cell_size, offset_x, offset_y, player_colors=None):
    """
    Основна логіка мультиплеєрної гри.
    connections: список сокетів (сервер: всі клієнти, клієнт: [сервер])
    is_server: True для сервера, False для клієнта
    player_colors: список кольорів для кожного гравця
    """
    if player_colors is None:
        player_colors = PLAYER_COLORS[:len(connections)+1]
    snakes = []
    for i in range(len(connections)+1):
        if i == 0:
            pos = (5, 5)
        elif i == 1:
            pos = (map_w-6, map_h-6)
        elif i == 2:
            pos = (5, map_h-6)
        else:
            pos = (map_w-6, 5)
        snakes.append(Snake(player_colors[i % len(player_colors)], pos))
    food = random_pos(snakes, map_w, map_h)
    started = [False for _ in snakes]
    clock = pygame.time.Clock()
    lose = [False for _ in snakes]
    msg = [""] * len(snakes)
    respawn_flags = [False for _ in snakes]

    if is_server:
        for conn in connections:
            conn.settimeout(0.2)
    else:
        connections[0].settimeout(0.2)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return
            elif event.type == pygame.KEYDOWN:
                idx = 0 if is_server else 1
                if event.key == pygame.K_ESCAPE:
                    return
                if not lose[idx]:
                    if event.key == pygame.K_UP:
                        snakes[idx].change_dir((0,-1))
                        started[idx] = True
                    if event.key == pygame.K_DOWN:
                        snakes[idx].change_dir((0,1))
                        started[idx] = True
                    if event.key == pygame.K_LEFT:
                        snakes[idx].change_dir((-1,0))
                        started[idx] = True
                    if event.key == pygame.K_RIGHT:
                        snakes[idx].change_dir((1,0))
                        started[idx] = True
                else:
                    if event.key == pygame.K_r:
                        respawn_flags[idx] = True

        if is_server:
            disconnected = []
            for i, conn in enumerate(connections):
                try:
                    data = recv_data(conn)
                    if data is None:
                        lose[i+1] = True
                        msg[i+1] = "Гравець відключився"
                        disconnected.append(i)
                        continue
                    started[i+1], snakes[i+1].dir, respawn = data
                    if respawn:
                        respawn_flags[i+1] = True
                except (socket.timeout, ConnectionResetError, OSError):
                    lose[i+1] = True
                    msg[i+1] = "Гравець відключився"
                    disconnected.append(i)
            for idx in sorted(disconnected, reverse=True):
                try:
                    connections[idx].close()
                except Exception:
                    pass
                del connections[idx]
                del snakes[idx+1]
                del started[idx+1]
                del lose[idx+1]
                del msg[idx+1]
                del respawn_flags[idx+1]
                if player_colors and len(player_colors) > len(connections)+1:
                    del player_colors[idx+1]
            if len(snakes) == 1:
                return
            if any(started):
                for i, s in enumerate(snakes):
                    if not lose[i]:
                        s.move()
                for s in snakes:
                    if s.body[0] == food:
                        s.eat()
                        food = random_pos(snakes, map_w, map_h)
                for idx, s in enumerate(snakes):
                    if lose[idx]:
                        continue
                    if s.out_of_bounds(map_w, map_h):
                        lose[idx] = True
                        msg[idx] = "Ви програли! Вийшли за межі."
                    elif len(s.body) > 3 and s.body[0] in s.body[1:]:
                        lose[idx] = True
                        msg[idx] = "Ви програли! Зіткнення із собою."
                    else:
                        for j, other in enumerate(snakes):
                            if j != idx and s.body[0] in other.body:
                                lose[idx] = True
                                msg[idx] = "Ви програли! Зіткнення з іншою змійкою."
                for i, flag in enumerate(respawn_flags):
                    if flag:
                        if i == 0:
                            snakes[i].body = [(5, 5)]
                            snakes[i].dir = (1, 0)
                        elif i == 1:
                            snakes[i].body = [(map_w-6, map_h-6)]
                            snakes[i].dir = (-1, 0)
                        elif i == 2:
                            snakes[i].body = [(5, map_h-6)]
                            snakes[i].dir = (1, 0)
                        else:
                            snakes[i].body = [(map_w-6, 5)]
                            snakes[i].dir = (-1, 0)
                        started[i] = False
                        lose[i] = False
                        msg[i] = ""
                        respawn_flags[i] = False
            for i, conn in enumerate(connections):
                try:
                    send_data(conn, (snakes, food, started, lose, msg))
                except Exception:
                    pass
        else:
            idx = 1
            try:
                send_data(connections[0], (started[idx], snakes[idx].dir, respawn_flags[idx]))
                data = recv_data(connections[0])
                if data is None:
                    return
                snakes_data, food, started, lose, msg = data
                for i in range(len(snakes)):
                    snakes[i].body = snakes_data[i].body
                    snakes[i].dir = snakes_data[i].dir
            except (socket.timeout, ConnectionResetError, OSError):
                return

        screen.fill((0,0,0))
        draw_snake_fullscreen(screen, snakes, cell_size, offset_x, offset_y)
        draw_food_fullscreen(screen, food, cell_size, offset_x, offset_y)
        if player_colors:
            for i, color in enumerate(player_colors[:len(snakes)]):
                rect = pygame.Rect(30 + i*110, 30, 80, 40)
                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, (255,255,255), rect, 2)
                num_txt = SMALL_FONT.render(str(i+1), True, (0,0,0) if sum(color)>400 else (255,255,255))
                screen.blit(num_txt, num_txt.get_rect(center=rect.center))
        idx = 0 if is_server else 1
        if lose[idx]:
            res = multiplayer_end_screen(screen, msg[idx])
            if res == "menu":
                return
            elif res == "respawn":
                respawn_flags[idx] = True
        pygame.display.flip()
        clock.tick(FPS)

def multiplayer_end_screen(screen, message):
    """
    Екран після програшу в мультиплеєрі (не зупиняє гру для інших).
    """
    btn_width = 320
    btn_height = 70
    btn_gap = 50
    center_x = screen.get_width() // 2
    start_y = 220

    menu_btn = Button((center_x - btn_width//2, start_y, btn_width, btn_height), "Головне меню")
    respawn_btn = Button((center_x - btn_width//2, start_y + btn_height + btn_gap, btn_width, btn_height), "Респавн (R)")
    clock = pygame.time.Clock()
    while True:
        screen.fill((30,30,30))
        draw_center_text(screen, message, 120, color=(255,80,80))
        menu_btn.draw(screen)
        respawn_btn.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if menu_btn.is_clicked(event.pos):
                    return "menu"
                if respawn_btn.is_clicked(event.pos):
                    return "respawn"
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    return "respawn"
        pygame.display.flip()
        clock.tick(30)

def main():
    """
    Основна функція запуску гри.
    Відкриває головне меню та запускає вибраний режим.
    """
    info = pygame.display.Info()
    screen = pygame.display.set_mode((info.current_w, info.current_h), pygame.FULLSCREEN)
    pygame.display.set_caption("Змійка")
    while True:
        mode, settings = menu_screen(screen)
        if mode == "host":
            host_game(screen, settings)
        elif mode == "join":
            join_game(screen, settings)
        elif mode == "solo":
            solo_game(screen, settings)

if __name__ == "__main__":
    main()