import subprocess
import sys
import importlib.util

def is_installed(package):
    return importlib.util.find_spec(package) is not None

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

if __name__ == "__main__":
    if not is_installed("pygame"):
        print("Встановлюємо pygame...")
        install("pygame")
    else:
        print("pygame вже встановлено.")

    if not is_installed("pyperclip"):
        print("Встановлюємо pyperclip...")
        install("pyperclip")
    else:
        print("pyperclip вже встановлено.")

    if not is_installed("psutil"):
        print("Встановлюємо psutil...")
        install("psutil")
    else:
        print("psutil вже встановлено.")

    print("Всі необхідні бібліотеки встановлені!")