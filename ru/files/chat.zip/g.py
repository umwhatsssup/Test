import socket
import time
import os
import subprocess
import sys

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def reg():
    input_user = input("Введите имя пользователя: ")
    input_pass = input("Введите пароль: ")
    max_attempts = 3

    # Проверка уникальности имени пользователя
    for attempt in range(1, max_attempts + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(3)
                clear_screen()
                print(f"Проверка имени пользователя (попытка {attempt} из {max_attempts})...")
                s.connect(("26.196.8.30", 12345))
                check_data = f"CHECK {input_user}\n".encode("utf-8")
                s.sendall(check_data)
                response = s.recv(1024)
                if response == b"EXISTS":
                    print("Пользователь с таким именем уже существует. Попробуйте другое имя.")
                    time.sleep(2)
                    return
                elif response == b"OK":
                    break  # Имя свободно, продолжаем регистрацию
                else:
                    print("Ошибка проверки имени пользователя.")
                    time.sleep(2)
                    return
        except Exception:
            print("Ошибка при проверке имени пользователя: Возможно, сервер недоступен.")
            time.sleep(2)
            if attempt < max_attempts:
                clear_screen()
            else:
                print("Не удалось проверить имя пользователя после 3 попыток.")
                print("Проверьте подключение к сети Radmin VPN или попробуйте позже.")
                time.sleep(2)
                return

    # Регистрация пользователя
    for attempt in range(1, max_attempts + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(3)
                clear_screen()
                print(f"Регистрация пользователя (попытка {attempt} из {max_attempts})...")
                s.connect(("26.196.8.30", 12345))
                data = f"REG {input_user} {input_pass}\n".encode("utf-8")
                s.sendall(data)
                print("Данные отправлены, ожидаем подтверждения от сервера...")
                response = s.recv(1024)
                if response == b"OK":
                    print("Сервер подтвердил регистрацию.")
                    time.sleep(3)
                    return
                else:
                    print("Ошибка регистрации на сервере.")
                    time.sleep(2)
                    return
        except Exception:
            print("Ошибка при отправке данных на сервер: Возможно, сервер в данное время недоступен.")
            time.sleep(2)
            if attempt < max_attempts:
                clear_screen()
            else:
                print("Не удалось подключиться к серверу после 3 попыток.")
                print("Пожалуйста, проверьте подключение к сети Radmin VPN или попробуйте позже.")
                time.sleep(2)
                return

def auth():
    input_user = input("Введите имя пользователя: ")
    input_pass = input("Введите пароль: ")
    max_attempts = 3
    for attempt in range(1, max_attempts + 1):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(3)
                clear_screen()
                print(f"Попытка подключения {attempt} из {max_attempts}...")
                s.connect(("26.196.8.30", 12345))
                data = f"AUTH {input_user} {input_pass}\n".encode("utf-8")
                s.sendall(data)
                print("Данные отправлены, ожидаем подтверждения от сервера...")
                response = s.recv(1024)
                if response == b"OK":
                    while True:
                        clear_screen()
                        print("1 - Войти в чаты\n2 - Выйти из аккаунта")
                        choice = input("Выберите действие: ")
                        if choice == "1":
                            subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), "main.py")])
                        elif choice == "2":
                            break
                        else:
                            print("Неверный выбор.")
                            time.sleep(2)
                    return True
                else:
                    print("Неверное имя пользователя или пароль.")
                    time.sleep(2)
                    return False
        except Exception:
            print("Ошибка при подключении к серверу: Возможно, сервер в данное время недоступен.")
            time.sleep(2)
            if attempt < max_attempts:
                clear_screen()
            else:
                print("Не удалось подключиться к серверу после 3 попыток.")
                print("Пожалуйста, проверьте подключение к сети Radmin VPN или попробуйте позже.")
                time.sleep(2)
    return False

def main():
    while True:
        clear_screen()
        print("Внимание!")
        print("Это программа для регистрации и авторизации пользователей через Radmin VPN.")
        print("Пожалуйста, убедитесь, что вы подключены к сети Radmin VPN.")
        print("И подключены на 'Server112233aa' с паролем '112233aa'.")
        try:
            choice = input("Выберите действие (1 - Регистрация, 2 - Авторизация, 3 - Выход): ")
        except (EOFError, KeyboardInterrupt):
            print("\nВыход из программы.")
            sys.exit(0)
        if choice == "1":
            reg()
        elif choice == "2":
            if auth():
                clear_screen()
                print("Вы успешно авторизованы!")
                time.sleep(3)
            else:
                clear_screen()
                print("Авторизация не удалась. Пожалуйста, попробуйте снова.")
                time.sleep(3)
        elif choice == "3":
            clear_screen()
            print("Выход из программы.")
            time.sleep(2)
            break
        else:
            clear_screen()
            print("Неверный выбор. Пожалуйста, попробуйте снова.")
            time.sleep(2)

if __name__ == "__main__":
    main()