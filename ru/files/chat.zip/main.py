import socket
import threading
import os
import sys

SERVER_IP = "26.196.8.30"
PORT = 12345

def receive(sock):
    while True:
        try:
            data = sock.recv(1024)
            if not data:
                print("\n[Server]: Соединение с сервером разорвано.")
                sys.exit(0)
            print("\r" + data.decode("utf-8") + "\n> ", end="")
        except:
            break

def chat_menu(sock):
    while True:
        print("\n1 - Создать чат\n2 - Войти в чат\n3 - Выйти из аккаунта")
        try:
            choice = input("Выберите действие: ")
        except (EOFError, KeyboardInterrupt):
            print("\n[Server]: Завершение работы клиента.")
            sys.exit(0)
        if choice == "1":
            chat_name = input("Название чата: ")
            chat_password = input("Пароль для чата: ")
            sock.sendall(f"CREATE_CHAT {chat_name} {chat_password}\n".encode("utf-8"))
            print("[Server]: Чат создается...")
            return True
        elif choice == "2":
            chat_id = input("ID чата: ")
            chat_password = input("Пароль для чата: ")
            sock.sendall(f"JOIN_CHAT {chat_id} {chat_password}\n".encode("utf-8"))
            print("[Server]: Вход в чат...")
            return True
        elif choice == "3":
            sock.sendall(b"LOGOUT\n")
            print("[Server]: Выход из аккаунта.")
            return False
        else:
            print("Неверный выбор.")

def chat_mode(sock):
    sock.sendall(b"GET_CHAT\n")
    recv_thread = threading.Thread(target=receive, args=(sock,), daemon=True)
    recv_thread.start()
    print("[Server]: Для выхода из чата введите /exit")
    while True:
        try:
            msg = input("> ")
        except (EOFError, KeyboardInterrupt):
            print("\n[Server]: Завершение работы клиента.")
            sock.sendall(b"LOGOUT\n")
            sys.exit(0)
        if msg.lower() == "/exit":
            sock.sendall(b"LOGOUT\n")
            print("[Server]: Выход из чата.")
            break
        sock.sendall(f"{msg}\n".encode("utf-8"))
    # recv_thread завершится автоматически при разрыве соединения

def main():
    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.connect((SERVER_IP, PORT))
            except Exception as e:
                print(f"[Ошибка]: Не удалось подключиться к серверу: {e}")
                return
            # Авторизация
            while True:
                try:
                    username = input("Имя пользователя: ")
                    password = input("Пароль: ")
                except (EOFError, KeyboardInterrupt):
                    print("\n[Server]: Завершение работы клиента.")
                    sys.exit(0)
                s.sendall(f"AUTH {username} {password}\n".encode("utf-8"))
                resp = s.recv(1024)
                if resp == b"OK":
                    print("[Server]: Авторизация успешна!")
                    break
                else:
                    print("[Server]: Ошибка авторизации. Попробуйте снова.")
            # Меню чата
            while True:
                if not chat_menu(s):
                    return
                chat_mode(s)
                try:
                    again = input("Войти в другой чат? (y/n): ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    print("\n[Server]: Завершение работы клиента.")
                    sys.exit(0)
                if again != "y":
                    print("[Server]: Выход из аккаунта.")
                    return

if __name__ == "__main__":
    main()